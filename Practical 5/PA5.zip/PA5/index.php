﻿<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <title></title>
</head>
<body>
    echo '<div class="text-center">Want to Leave the Page? <br><br><br><a href="logout.php">Logout</a></div>';
</body>
</html>