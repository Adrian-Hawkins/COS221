<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>Sports Statistics</title>
        <link rel="stylesheet" type="text/css" href="css\header.css">
    </head>
    <body>
        <header>
            <nav>
                <ul>
                    <li><a href="#">Add Player</a></li>
                    <li><a href="#">Add Event</a></li>
                    <li><a href="#">Manage Event</a></li>
                    <li><a href="#">View Statistics</a></li>
                    <li><a href="#">Login</a></li>
                </ul>
            </nav>
        </header>
    </body>
</html>